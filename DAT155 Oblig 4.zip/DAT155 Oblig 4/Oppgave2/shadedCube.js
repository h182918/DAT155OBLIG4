"use strict";



var canvas;
var gl;

var numVertices  = 36;
var numTimesToSubdivide = 3;
var index = 0;
var pointsArray = [];
var normalsArray = [];
var sPointsArray = [];
var sNormalsArray = [];
var nBuffer;
var vBuffer;
var sBuffer;
var tBuffer;
//----------------
    var eye;
    var at = vec3(0.0, 0.0, 0.0);
    var up = vec3(0.0, 1.0, 0.0);



    var near = -10;
    var far = 10;
    var radius = 1.5;
    var theta  = 0.0;
    var phi    = 0.0;
    var dr = 5.0 * Math.PI/180.0;

    var left = -3.0;
    var right = 3.0;
    var ytop =3.0;
    var bottom = -3.0;
    //---------

var va = vec4(0.0, 0.0, -1.0,1);
var vb = vec4(0.0, 0.942809, 0.333333, 1);
var vc = vec4(-0.816497, -0.471405, 0.333333, 1);
var vd = vec4(0.816497, -0.471405, 0.333333,1);

var vertices = [
        vec4( -0.5, -0.5,  0.5, 1.0 ),
        vec4( -0.5,  0.5,  0.5, 1.0 ),
        vec4( 0.5,  0.5,  0.5, 1.0 ),
        vec4( 0.5, -0.5,  0.5, 1.0 ),
        vec4( -0.5, -0.5, -0.5, 1.0 ),
        vec4( -0.5,  0.5, -0.5, 1.0 ),
        vec4( 0.5,  0.5, -0.5, 1.0 ),
        vec4( 0.5, -0.5, -0.5, 1.0 )
    ];

var lightPosition = vec4(1.0, 1.0, 1.0, 0.0 );
var lightAmbient = vec4(0.2, 0.2, 0.2, 1.0 );
var lightDiffuse = vec4( 1.0, 1.0, 1.0, 1.0 );
var lightSpecular = vec4( 1.0, 1.0, 1.0, 1.0 );

var materialAmbient = vec4( 0.19225, 0.19225, 0.19225, 1.0 );
var materialDiffuse = vec4( 0.50754, 0.50754, 0.50754, 1.0);
var materialSpecular = vec4( 0.508273, 0.508273, 0.508273, 1.0 );
var materialShininess = 51.2;

var materialAmbient2 = vec4( 0.2125, 0.1275, 0.054, 1.0 );
var materialDiffuse2 = vec4( 0.714, 0.4284, 0.18144, 1.0);
var materialSpecular2 = vec4( 0.393548, 0.271906, 0.166721, 1.0 );
var materialShininess2 = 25.6;

var materialAmbient3 = vec4( 1.0, 0.0, 1.0, 1.0 );
var materialDiffuse3 = vec4( 1.0, 0.8, 0.0, 1.0 );
var materialSpecular3 = vec4( 1.0, 1.0, 1.0, 1.0 );
var materialShininess3 = 20.0;

var ctm;
var ambientColor, diffuseColor, specularColor;
var modelViewMatrix, projectionMatrix;
var modelViewMatrixLoc, projectionMatrixLoc;

var nMatrix, nMatrixLoc;
var viewerPos;
var cubeProgram;
var cubeProgram2;
var sphereProgram;

var xAxis = 0;
var yAxis = 1;
var zAxis = 2;
var axis = 0;
var theta = vec3(0, 0, 0);

var thetaLoc;
var flag = false;

function quad(a, b, c, d) {

     var t1 = subtract(vertices[b], vertices[a]);
     var t2 = subtract(vertices[c], vertices[b]);
     var normal = cross(t1, t2);
     normal = vec3(normal);

     pointsArray.push(vertices[a]);
     normalsArray.push(normal);
     pointsArray.push(vertices[b]);
     normalsArray.push(normal);
     pointsArray.push(vertices[c]);
     normalsArray.push(normal);
     pointsArray.push(vertices[a]);
     normalsArray.push(normal);
     pointsArray.push(vertices[c]);
     normalsArray.push(normal);
     pointsArray.push(vertices[d]);
     normalsArray.push(normal);
}


function colorCube()
{
    quad( 1, 0, 3, 2 );
    quad( 2, 3, 7, 6 );
    quad( 3, 0, 4, 7 );
    quad( 6, 5, 1, 2 );
    quad( 4, 5, 6, 7 );
    quad( 5, 4, 0, 1 );
}

    function triangle(a, b, c) {

        sPointsArray.push(a);
        sPointsArray.push(b);
        sPointsArray.push(c);

        // normals are vectors
        a = normalize(vec3(a[0],a[1], a[2]));
        b = normalize(vec3(b[0],b[1], b[2]));
        c = normalize(vec3(c[0],c[1], c[2]));
        sNormalsArray.push(vec4(a[0],a[1], a[2], 0.0));
        sNormalsArray.push(vec4(b[0],b[1], b[2], 0.0));
        sNormalsArray.push(vec4(c[0],c[1], c[2], 0.0));
        index += 3;
    }


    function divideTriangle(a, b, c, count) {
        if ( count > 0 ) {

            var ab = mix( a, b, 0.5);
            var ac = mix( a, c, 0.5);
            var bc = mix( b, c, 0.5);

            ab = normalize(ab, true);
            ac = normalize(ac, true);
            bc = normalize(bc, true);

            divideTriangle( a, ab, ac, count - 1 );
            divideTriangle( ab, b, bc, count - 1 );
            divideTriangle( bc, c, ac, count - 1 );
            divideTriangle( ab, bc, ac, count - 1 );
        }
        else {
            triangle( a, b, c );
        }
    }


    function tetrahedron(a, b, c, d, n) {
        divideTriangle(a, b, c, n);
        divideTriangle(d, c, b, n);
        divideTriangle(a, d, b, n);
        divideTriangle(a, c, d, n);
    }



window.onload = function init() {
    canvas = document.getElementById( "gl-canvas" );

    gl = canvas.getContext('webgl2');
    if (!gl) { alert( "WebGL 2.0 isn't available" ); }


    gl.viewport( 0, 0, canvas.width, canvas.height );
    gl.clearColor( 1.0, 1.0, 1.0, 1.0 );

    gl.enable(gl.DEPTH_TEST);

    //
    //  Load shaders and initialize attribute buffers
    //

    cubeProgram = initShaders( gl, "./shapeShaders/vCubeShader.glsl", "./shapeShaders/fCubeShader.glsl" ); // shaderne kan ligge egne filer.
    cubeProgram2 = initShaders( gl, "./shapeShaders/vCubeShader2.glsl", "./shapeShaders/fCubeShader2.glsl" );
    sphereProgram = initShaders(gl, "./shapeShaders/vSphereShader.glsl", "./shapeShaders/fSphereShader.glsl");

    projectionMatrix = ortho(-1, 1, -1, 1, -100, 100);

    // //First cube----------------------------------------------------------------------------------------------------------
    gl.useProgram( cubeProgram );

    colorCube();

    nBuffer = gl.createBuffer();
    gl.bindBuffer( gl.ARRAY_BUFFER, nBuffer );
    gl.bufferData( gl.ARRAY_BUFFER, flatten(normalsArray), gl.STATIC_DRAW );

    var normalLoc = gl.getAttribLocation( cubeProgram, "aNormal" );
    gl.vertexAttribPointer( normalLoc, 3, gl.FLOAT, false, 0, 0 );
    gl.enableVertexAttribArray( normalLoc );

    vBuffer = gl.createBuffer();
    gl.bindBuffer( gl.ARRAY_BUFFER, vBuffer );
    gl.bufferData( gl.ARRAY_BUFFER, flatten(pointsArray), gl.STATIC_DRAW );

    var positionLoc = gl.getAttribLocation(cubeProgram, "aPosition");
    gl.vertexAttribPointer(positionLoc, 4, gl.FLOAT, false, 0, 0);
    gl.enableVertexAttribArray(positionLoc);

    thetaLoc = gl.getUniformLocation(cubeProgram, "theta");

    viewerPos = vec3(0.0, 0.0, -20.0 );

    var ambientProduct = mult(lightAmbient, materialAmbient);
    var diffuseProduct = mult(lightDiffuse, materialDiffuse);
    var specularProduct = mult(lightSpecular, materialSpecular);

    gl.uniform4fv(gl.getUniformLocation(cubeProgram, "ambientProduct"),
        ambientProduct);
    gl.uniform4fv(gl.getUniformLocation(cubeProgram, "diffuseProduct"),
        diffuseProduct );
    gl.uniform4fv(gl.getUniformLocation(cubeProgram, "specularProduct"),
        specularProduct );
    gl.uniform4fv(gl.getUniformLocation(cubeProgram, "lightPosition"),
        lightPosition );

    gl.uniform1f(gl.getUniformLocation(cubeProgram,
        "shininess"),materialShininess);

    gl.uniformMatrix4fv( gl.getUniformLocation(cubeProgram, "projectionMatrix"),
        false, flatten(projectionMatrix));

    // Cube2-------------------------------------------------------------------------------------------------------------------------
    gl.useProgram(cubeProgram2);

    colorCube();

    gl.bindBuffer( gl.ARRAY_BUFFER, nBuffer );

    var normalLoc = gl.getAttribLocation( cubeProgram2, "aNormal" );
    gl.vertexAttribPointer( normalLoc, 3, gl.FLOAT, false, 0, 0 );
    gl.enableVertexAttribArray( normalLoc );


    gl.bindBuffer( gl.ARRAY_BUFFER, vBuffer );


    var positionLoc = gl.getAttribLocation(cubeProgram2, "aPosition");
    gl.vertexAttribPointer(positionLoc, 4, gl.FLOAT, false, 0, 0);
    gl.enableVertexAttribArray(positionLoc);

    thetaLoc = gl.getUniformLocation(cubeProgram2, "theta");

    viewerPos = vec3(0.0, 0.0, -50.0 );

    var ambientProduct = mult(lightAmbient, materialAmbient2);
    var diffuseProduct = mult(lightDiffuse, materialDiffuse2);
    var specularProduct = mult(lightSpecular, materialSpecular2);

    gl.uniform4fv(gl.getUniformLocation(cubeProgram2, "ambientProduct"),
        ambientProduct);
    gl.uniform4fv(gl.getUniformLocation(cubeProgram2, "diffuseProduct"),
        diffuseProduct );
    gl.uniform4fv(gl.getUniformLocation(cubeProgram2, "specularProduct"),
        specularProduct );
    gl.uniform4fv(gl.getUniformLocation(cubeProgram2, "lightPosition"),
        lightPosition );

    gl.uniform1f(gl.getUniformLocation(cubeProgram2,
        "shininess"),materialShininess2);

    gl.uniformMatrix4fv( gl.getUniformLocation(cubeProgram2, "projectionMatrix"),
        false, flatten(projectionMatrix));

    //-----------------------------------------------------------------------------------------------
    gl.useProgram(sphereProgram);

    var ambientProduct = mult(lightAmbient, materialAmbient3);
    var diffuseProduct = mult(lightDiffuse, materialDiffuse3);
    var specularProduct = mult(lightSpecular, materialSpecular3);

    tetrahedron(va, vb, vc, vd, 4);
    sBuffer = gl.createBuffer();
    gl.bindBuffer( gl.ARRAY_BUFFER, sBuffer);
    gl.bufferData( gl.ARRAY_BUFFER, flatten(sNormalsArray), gl.STATIC_DRAW);

    var sNormalLoc = gl.getAttribLocation( sphereProgram, "aNormal" );
    gl.vertexAttribPointer( sNormalLoc, 3, gl.FLOAT, false, 0, 0 );
    gl.enableVertexAttribArray( sNormalLoc);

    tBuffer = gl.createBuffer();
    gl.bindBuffer( gl.ARRAY_BUFFER, tBuffer);
    gl.bufferData( gl.ARRAY_BUFFER, flatten(sPointsArray), gl.STATIC_DRAW);

    var sPositionLoc = gl.getAttribLocation( sphereProgram, "aPosition");
    gl.bindBuffer( gl.ARRAY_BUFFER, tBuffer);
    gl.vertexAttribPointer(sPositionLoc, 4, gl.FLOAT, false, 0, 0);
    gl.enableVertexAttribArray(sPositionLoc);

    modelViewMatrixLoc = gl.getUniformLocation( sphereProgram, "modelViewMatrix" );
    projectionMatrixLoc = gl.getUniformLocation( sphereProgram, "projectionMatrix" );
    nMatrixLoc = gl.getUniformLocation( sphereProgram, "normalMatrix" );

    gl.uniformMatrix4fv( gl.getUniformLocation(sphereProgram, "projectionMatrix"),
        false, flatten(projectionMatrix));
    gl.uniform4fv( gl.getUniformLocation(sphereProgram,
        "ambientProduct"),flatten(ambientProduct) );
    gl.uniform4fv( gl.getUniformLocation(sphereProgram,
        "diffuseProduct"),flatten(diffuseProduct) );
    gl.uniform4fv( gl.getUniformLocation(sphereProgram,
        "specularProduct"),flatten(specularProduct) );
    gl.uniform4fv( gl.getUniformLocation(sphereProgram,
        "lightPosition"),flatten(lightPosition) );
    gl.uniform1f( gl.getUniformLocation(sphereProgram,
        "shininess"),materialShininess3 );

    document.getElementById("ButtonX").onclick = function(){axis = xAxis;};
    document.getElementById("ButtonY").onclick = function(){axis = yAxis;};
    document.getElementById("ButtonZ").onclick = function(){axis = zAxis;};
    document.getElementById("ButtonT").onclick = function(){flag = !flag;};

    render();
}

var render = function(){

    gl.clear( gl.COLOR_BUFFER_BIT | gl.DEPTH_BUFFER_BIT);

    if(flag) theta[axis] += 2.0;

    gl.bindBuffer( gl.ARRAY_BUFFER, nBuffer );
    gl.vertexAttribPointer( gl.getAttribLocation( cubeProgram, "aNormal" ), 3, gl.FLOAT, false, 0, 0 );
    gl.enableVertexAttribArray( gl.getAttribLocation( cubeProgram, "aNormal" ) );

    gl.useProgram(cubeProgram);
    gl.bindBuffer( gl.ARRAY_BUFFER, nBuffer );
    gl.vertexAttribPointer( gl.getAttribLocation( cubeProgram, "aNormal" ), 3, gl.FLOAT, false, 0, 0 );
    gl.enableVertexAttribArray( gl.getAttribLocation( cubeProgram, "aNormal" ) );
    gl.bindBuffer( gl.ARRAY_BUFFER, vBuffer );
    gl.vertexAttribPointer(gl.getAttribLocation(cubeProgram, "aPosition"), 4, gl.FLOAT, false, 0, 0);
    gl.enableVertexAttribArray(gl.getAttribLocation(cubeProgram, "aPosition"));
    modelViewMatrix = mat4();
    modelViewMatrix = mult(modelViewMatrix, translate(-0.5,0.5,0));
    modelViewMatrix = mult(modelViewMatrix, scale(0.5,0.5,0.5));
    modelViewMatrix = mult(modelViewMatrix, rotate(theta[xAxis], vec3(1, 0, 0) ));
    modelViewMatrix = mult(modelViewMatrix, rotate(theta[yAxis], vec3(0, 1, 0) ));
    modelViewMatrix = mult(modelViewMatrix, rotate(theta[zAxis], vec3(0, 0, 1) ));
    gl.uniformMatrix4fv( gl.getUniformLocation(cubeProgram,
        "modelViewMatrix"), false, flatten(modelViewMatrix) );

    gl.drawArrays( gl.TRIANGLES, 0, numVertices );

    gl.useProgram(cubeProgram2);
    gl.bindBuffer( gl.ARRAY_BUFFER, nBuffer );
    gl.vertexAttribPointer( gl.getAttribLocation( cubeProgram2, "aNormal" ), 3, gl.FLOAT, false, 0, 0 );
    gl.enableVertexAttribArray( gl.getAttribLocation( cubeProgram2, "aNormal" ) );
    gl.bindBuffer( gl.ARRAY_BUFFER, vBuffer );
    gl.vertexAttribPointer(gl.getAttribLocation(cubeProgram2, "aPosition"), 4, gl.FLOAT, false, 0, 0);
    gl.enableVertexAttribArray(gl.getAttribLocation(cubeProgram2, "aPosition"));
    modelViewMatrix = mat4();
    modelViewMatrix = mult(modelViewMatrix, translate(0.5,0.5,0));
    modelViewMatrix = mult(modelViewMatrix, scale(0.5, 0.5, 0.5));
    modelViewMatrix = mult(modelViewMatrix, rotate(theta[xAxis], vec3(1, 0, 0) ));
    modelViewMatrix = mult(modelViewMatrix, rotate(theta[yAxis], vec3(0, 1, 0) ));
    modelViewMatrix = mult(modelViewMatrix, rotate(theta[zAxis], vec3(0, 0, 1) ));

    gl.uniformMatrix4fv( gl.getUniformLocation(cubeProgram2,
            "modelViewMatrix"), false, flatten(modelViewMatrix) );

    gl.drawArrays( gl.TRIANGLES, 0, numVertices );

    gl.useProgram(sphereProgram);
    gl.bindBuffer( gl.ARRAY_BUFFER, sBuffer);
    gl.vertexAttribPointer( gl.getAttribLocation( sphereProgram, "aNormal" ), 3, gl.FLOAT, false, 0, 0 );
    gl.enableVertexAttribArray( gl.getAttribLocation( sphereProgram, "aNormal" ));
    gl.bindBuffer( gl.ARRAY_BUFFER, tBuffer);
    gl.vertexAttribPointer(gl.getAttribLocation( sphereProgram, "aPosition"), 4, gl.FLOAT, false, 0, 0);
    gl.enableVertexAttribArray(gl.getAttribLocation( sphereProgram, "aPosition"));

    modelViewMatrix = mat4();
    modelViewMatrix = mult(modelViewMatrix, translate(0.0,0,0));
    modelViewMatrix = mult(modelViewMatrix, scale(0.3, 0.3, 0.3));
    modelViewMatrix = mult(modelViewMatrix, rotate(theta[xAxis], vec3(1, 0, 0) ));
    modelViewMatrix = mult(modelViewMatrix, rotate(theta[yAxis], vec3(0, 1, 0) ));
    modelViewMatrix = mult(modelViewMatrix, rotate(theta[zAxis], vec3(0, 0, 1) ));
    //projectionMatrix = ortho(left, right, bottom, ytop, near, far);

    nMatrix = normalMatrix(modelViewMatrix, true );

    gl.uniformMatrix4fv(modelViewMatrixLoc, false, flatten(modelViewMatrix)  );
    gl.uniformMatrix4fv(projectionMatrixLoc, false, flatten(projectionMatrix)  );
    gl.uniformMatrix3fv(nMatrixLoc, false, flatten(nMatrix) );

    gl.drawArrays( gl.TRIANGLES, 0, sPointsArray.length );

    requestAnimationFrame(render);
}




